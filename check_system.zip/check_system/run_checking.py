from contents import system_checkup

if __name__ == "__main__":
    system_checkup()
